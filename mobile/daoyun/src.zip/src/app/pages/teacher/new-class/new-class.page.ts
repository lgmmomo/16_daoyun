import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-class',
  templateUrl: './new-class.page.html',
  styleUrls: ['./new-class.page.scss'],
})
export class NewClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
