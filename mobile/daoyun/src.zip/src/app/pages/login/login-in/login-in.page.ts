import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-in',
  templateUrl: './login-in.page.html',
  styleUrls: ['./login-in.page.scss'],
})
export class LoginInPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
