import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gesture-sign-in',
  templateUrl: './gesture-sign-in.page.html',
  styleUrls: ['./gesture-sign-in.page.scss'],
})
export class GestureSignInPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
