import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-gesture',
  templateUrl: './make-gesture.page.html',
  styleUrls: ['./make-gesture.page.scss'],
})
export class MakeGesturePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
