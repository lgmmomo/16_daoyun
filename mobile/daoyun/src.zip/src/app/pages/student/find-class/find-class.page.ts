import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-class',
  templateUrl: './find-class.page.html',
  styleUrls: ['./find-class.page.scss'],
})
export class FindClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
