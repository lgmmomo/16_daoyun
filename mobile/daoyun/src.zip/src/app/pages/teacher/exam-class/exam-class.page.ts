import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exam-class',
  templateUrl: './exam-class.page.html',
  styleUrls: ['./exam-class.page.scss'],
})
export class ExamClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
