import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-information',
  templateUrl: './set-information.page.html',
  styleUrls: ['./set-information.page.scss'],
})
export class SetInformationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
