import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-class',
  templateUrl: './view-class.page.html',
  styleUrls: ['./view-class.page.scss'],
})
export class ViewClassPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
