import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exam-sign-in',
  templateUrl: './exam-sign-in.page.html',
  styleUrls: ['./exam-sign-in.page.scss'],
})
export class ExamSignInPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
